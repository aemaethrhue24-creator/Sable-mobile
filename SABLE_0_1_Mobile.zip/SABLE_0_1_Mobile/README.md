# SABLE 0.1 — Mobile prototype

Mobile-first installable web app intended for Android and iPhone browsers.

## Features
- Black, silver and electric-blue SABLE interface
- Responsive mobile layout
- Local demo conversation (not connected to a live AI model)
- Tap-to-use speech recognition where supported by the browser
- On-device notes stored in browser local storage
- PWA manifest and basic offline cache

## Limitations
This is a front-end prototype. It does not control your phone, access other apps, send messages, make purchases, or listen in the background. Voice input starts only when you tap the microphone. Replies are sample local responses.

## Run and install
Host this folder on an HTTPS static host, open it on your phone, then use your browser menu and choose **Install app** or **Add to Home screen**. For local computer testing, run `python -m http.server 8000` in this folder and open `http://localhost:8000`.

## Next step
Connect the interface to a secure backend that calls an AI model. Keep API keys on the backend, never in the HTML or app bundle. Add permission and confirmation screens before enabling device actions.
